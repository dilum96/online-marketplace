package com.example.online_marketplace_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMarketplaceProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
