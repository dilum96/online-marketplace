package com.example.online_marketplace_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineMarketplaceProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnlineMarketplaceProjectApplication.class, args);
    }

}
