package com.example.online_marketplace_project.user;

import javax.persistence.*;

@Entity
@Table(name = "users")
public class user {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true, length = 45)
    private String email;

    @Column(length = 15, nullable = false)
    private String password;

    @Column(length = 15, nullable = false, name = "first _name")
    private String firstName;

    @Column(length = 15, nullable = false, name = "last _name")
    private String lastName;

}
